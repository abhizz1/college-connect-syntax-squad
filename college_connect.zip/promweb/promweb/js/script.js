// College Connect - Main JavaScript File

// Function to validate login form
function validateLoginForm(event) {
    event.preventDefault(); // Prevent form submission

    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;
    const errorMessage = document.getElementById('error-message');

    // Basic validation
    if (username === '' || password === '') {
        errorMessage.textContent = 'Please fill in all fields.';
        errorMessage.classList.remove('hidden');
    } else {
        // Simulate successful login
        localStorage.setItem('loggedIn', true);
        window.location.href = 'home.html'; // Redirect to homepage
    }
}

// Function to validate contact form
function validateContactForm(event) {
    event.preventDefault(); // Prevent form submission

    const name = document.getElementById('name').value;
    const email = document.getElementById('email').value;
    const subject = document.getElementById('subject').value;
    const message = document.getElementById('message').value;
    const errorMessage = document.getElementById('contact-error');
    const successMessage = document.getElementById('contact-success');

    // Basic validation
    if (name === '' || email === '' || subject === '' || message === '') {
        errorMessage.textContent = 'Please fill in all fields.';
        errorMessage.classList.remove('hidden');
        successMessage.style.display = 'none';
    } else if (!isValidEmail(email)) {
        errorMessage.textContent = 'Please enter a valid email address.';
        errorMessage.classList.remove('hidden');
        successMessage.style.display = 'none';
    } else {
        // Form is valid
        errorMessage.classList.add('hidden');
        successMessage.style.display = 'block';
        
        // Clear form
        document.getElementById('contact-form').reset();
        
        // Hide success message after 3 seconds
        setTimeout(() => {
            successMessage.style.display = 'none';
        }, 3000);
    }
}

// Function to validate email format
function isValidEmail(email) {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
}

// Function to check login status
function checkLoginStatus() {
    const loggedIn = localStorage.getItem('loggedIn');
    if (!loggedIn) {
        window.location.href = 'index.html'; // Redirect to login if not logged in
    }
}

// Add event listeners
document.addEventListener('DOMContentLoaded', () => {
    const loginForm = document.getElementById('login-form');
    if (loginForm) {
        loginForm.addEventListener('submit', validateLoginForm);
    }

    const contactForm = document.getElementById('contact-form');
    if (contactForm) {
        contactForm.addEventListener('submit', validateContactForm);
    }

    // Check login status on homepage
    if (document.body.classList.contains('home-page')) {
        checkLoginStatus();
    }
});
